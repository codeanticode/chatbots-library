// Decompiled by Jad v1.5.8c. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package org.alicebot.server.core.processor.loadtime;

import org.alicebot.server.core.processor.ProcessorException;

public class InvalidStartupElementException extends ProcessorException
{

    public InvalidStartupElementException(String s)
    {
        super(s);
    }
}
