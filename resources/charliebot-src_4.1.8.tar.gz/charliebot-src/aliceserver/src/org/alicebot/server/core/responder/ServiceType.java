// Decompiled by Jad v1.5.8c. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package org.alicebot.server.core.responder;


class ServiceType
{

    ServiceType()
    {
    }

    public static final int UNKNOWN = 0;
    public static final int PLAIN_TEXT = 1;
    public static final int HTML = 2;
    public static final int FLASH = 3;
}
