//
//  java_util.java
//  java_util
//
//  Created by Aaron Rosenzweig on Fri Oct 25 2002.
//  Copyright (c) 2002 __MyCompanyName__. All rights reserved.
//
import java.util.*;

public class java_util {

    public static void main (String args[]) {
        // insert code here...
        System.out.println("Hello World!");
    }
}
