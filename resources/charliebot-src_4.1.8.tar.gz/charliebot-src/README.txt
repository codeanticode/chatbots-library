Maintained by Aaron Rosenzweig -> aaron@cocoanutstech.com
Charlie is available at the following two places:
1) www.cocoanutstech.com
2) sourceforge.net

The source here could be compiled in any Java programming tool but these already have Project Builder projects set up for Mac OS X.

aliceserver folder
======================
This is the source code to Program D (Charlie)


linkedHashMap folder
======================
This contains the necessary source to create part of the java.util package from Java 1.4 so that we can use it in Java 1.3